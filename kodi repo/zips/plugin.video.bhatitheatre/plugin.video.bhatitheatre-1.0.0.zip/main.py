import sys, urllib.parse, xbmcplugin, xbmcgui, xbmcaddon, requests
from bs4 import BeautifulSoup

addon = xbmcaddon.Addon()
handle = int(sys.argv[1])
base = sys.argv[0]
api = 'b6b677eb7d4ec17f700e3d4dfc31d005'  # Replace this with your real TMDb API key
tmdb = 'https://api.themoviedb.org/3'

def build(query): return base + '?' + urllib.parse.urlencode(query)

def menu():
    xbmcplugin.setContent(handle, 'movies')
    items = [
        ('Trending (Hindi)', 'trending'),
        ('Comedy', 'genre', '35'),
        ('Romance', 'genre', '10749'),
        ('Action', 'genre', '28'),
        ('Search', 'search')
    ]
    for title, act, *extra in items:
        q = {'action': act}
        if extra: q['genre'] = extra[0]
        xbmcplugin.addDirectoryItem(handle, build(q), xbmcgui.ListItem(title), True)
    xbmcplugin.endOfDirectory(handle)

def list_movies(action, genre=None):
    if action == 'trending':
        url = f"{tmdb}/trending/movie/day?api_key={api}&region=IN&with_original_language=hi"
    else:
        url = f"{tmdb}/discover/movie?api_key={api}&with_genres={genre}&region=IN&with_original_language=hi"
    res = requests.get(url).json().get('results', [])
    for m in res:
        title = m.get('title')
        li = xbmcgui.ListItem(label=title)
        xbmcplugin.addDirectoryItem(handle,
            build({'action': 'play', 'id': m.get('id')}), li, False)
    xbmcplugin.endOfDirectory(handle)

def search_dialog():
    q = xbmcgui.Dialog().input("Search Movie", type=xbmcgui.INPUT_ALPHANUM)
    if not q: return
    query = urllib.parse.quote(q)
    url = f"{tmdb}/search/movie?api_key={api}&query={query}&region=IN&with_original_language=hi"
    res = requests.get(url).json().get('results', [])
    for m in res:
        li = xbmcgui.ListItem(m.get('title'))
        xbmcplugin.addDirectoryItem(handle,
            build({'action': 'play', 'id': m.get('id')}), li, False)
    xbmcplugin.endOfDirectory(handle)

def play(id):
    iframe = f"https://www.2embed.cc/embed/movie?tmdb={id}"
    html = requests.get(iframe).text
    soup = BeautifulSoup(html, 'html.parser')
    src = soup.find('iframe').get('src')
    r = requests.get(src).text
    video = BeautifulSoup(r, 'html.parser').find('source').get('src')
    li = xbmcgui.ListItem(path=video)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle, True, li)

if __name__ == '__main__':
    args = urllib.parse.parse_qs(sys.argv[2][1:])
    act = args.get('action', [None])[0]
    if not act: menu()
    elif act in ['trending', 'genre']: list_movies(act, args.get('genre', [None])[0])
    elif act == 'search': search_dialog()
    elif act == 'play': play(args['id'][0])
